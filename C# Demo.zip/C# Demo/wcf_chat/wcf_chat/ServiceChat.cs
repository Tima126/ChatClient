﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Data.SqlClient;
using System.Text;

namespace wcf_chat
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class ServiceChat : IServiceChat
    {
        List<Serveruser> users = new List<Serveruser>();

        int nextID = 1;


    


        public int Connect(string name)
        {
            Serveruser user = new Serveruser()
            {
                id = nextID,
                Name = name,
                operationContext = OperationContext.Current
                
            
            };

            nextID++;

            SendMessag(user.Name + "Подключился к чату!",0);
            users.Add(user);
            return user.id;
            
        }

        public void Disconnect(int id)
        {
           var user = users.FirstOrDefault(x => x.id == id);
            if (user!=null)
            {
                users.Remove(user);
                SendMessag(user.Name + "Покинул чат",0);
            }
        }



        public void SendMessag(string messag, int id)
        {
            foreach (Serveruser item in users)
            {
                string answer = DateTime.Now.ToShortTimeString();
                
                var user = users.FirstOrDefault(x => x.id == id);

                if (user != null)
                {
                    answer += ": " + user.Name + " ";
                }
                answer += messag;
                item.operationContext.GetCallbackChannel<IsServerCallbackChat>().MsgCallBack(answer);

            }
        }
    }
}
