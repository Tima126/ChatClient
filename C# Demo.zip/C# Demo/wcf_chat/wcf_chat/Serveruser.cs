﻿using System.ServiceModel;

namespace wcf_chat
{
    public class Serveruser
    {
        public int id { get; set; }
        public string Name { get; set; }
        public OperationContext operationContext { get; set; }

    }
}
