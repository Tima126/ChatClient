﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ChatClient.ServiceChat;

namespace ChatClient
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IServiceChatCallback
    {
        bool isconnect = false;
        ServiceChatClient client;
        int ID;





        public MainWindow()
        {
            InitializeComponent();
        }

        void ConnectUser()
        {
            if (!isconnect)
            {
                client = new ServiceChatClient(new System.ServiceModel.InstanceContext(this));
                ID = client.Connect(tbusername.Text);

                AddUserToDatabase(tbusername.Text, ID);
                tbusername.IsEnabled = false;
                BtDisConect.Content = "Disconnect";
                isconnect = true;
            }
        }
        private void AddUserToDatabase(string userName, int userId)
        {
            string connectionString = "Data Source=DESKTOP-TV374V6;Initial Catalog=chatUser;Integrated Security=True;Encrypt=False";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkUserQuery = "SELECT COUNT(*) FROM Users WHERE Name = @Name";
               
                using (SqlCommand checkUserCommand = new SqlCommand(checkUserQuery, connection))
                {
                    checkUserCommand.Parameters.AddWithValue("@Name", userName);
                    int count = (int)checkUserCommand.ExecuteScalar();

        
                    if (count == 0)
                    {
                        string insertUserQuery = "INSERT INTO Users (id, Name) VALUES (@id, @Name)";
                        using (SqlCommand insertUserCommand = new SqlCommand(insertUserQuery, connection))
                        {
                            insertUserCommand.Parameters.AddWithValue("@id", userId);
                            insertUserCommand.Parameters.AddWithValue("@Name", userName);
                            insertUserCommand.ExecuteNonQuery();
                        }
                    }
                }
            }
        }


        private void SaveMessageToDatabase(int userId, string messageText)
        {
            string connectionString = "Data Source=DESKTOP-TV374V6;Initial Catalog=chatUser;Integrated Security=True;Encrypt=False";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertMessageQuery = "INSERT INTO Messages (UserID, MessageText) VALUES (@UserID, @MessageText)";
                using (SqlCommand insertMessageCommand = new SqlCommand(insertMessageQuery, connection))
                {
                    insertMessageCommand.Parameters.AddWithValue("@UserID", userId);
                    insertMessageCommand.Parameters.AddWithValue("@MessageText", messageText);
                    insertMessageCommand.ExecuteNonQuery();
                }
            }
        }

        void DisconnectUser()
        {
            if (isconnect)
            {
                client.Disconnect(ID); // Уведомление сервера о отключении
                client.Close(); // Закрытие соединения клиента
                client = null;
                tbusername.IsEnabled = true;
                BtDisConect.Content = "Connect";
                isconnect = false;
            }
        }


        private void BtDisConect_Click(object sender, RoutedEventArgs e)
        {
            if (isconnect)
            {
                DisconnectUser();

            }
            else
            {
                ConnectUser();
            }

        }

        public void MsgCallBack(string msg)
        {
            lbChat.Items.Add(msg);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            DisconnectUser();
        }

        private void tbMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (client != null)
                {
                    SaveMessageToDatabase(ID, tbMessage.Text);
                    client.SendMessag(tbMessage.Text, ID);
                    tbMessage.Text = string.Empty;
                }

            }
        }
    }
}
